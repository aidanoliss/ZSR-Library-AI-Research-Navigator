# Wake Forest ZSR Library AI Research Navigator

Prototype AI research-planning assistant for Wake Forest Z. Smith Reynolds Library workflows.

The app helps students turn a topic into search terms, mode-specific research strategies, ZSR starting points, live catalog leads when available, citation guidance, and full-text access next steps.

This is a prototype, not a production ZSR integration. It does not log students into ZSR, bypass paywalls, control LibKey Nomad, or expose private keys in the browser.

## What It Does

- Suggests better search terms and Boolean variants.
- Recommends ZSR-style starting points and research modes.
- Links out to Google Scholar, ZSR discovery, ZSR citation resources, and ZSR help paths.
- Runs a best-effort live Primo/ZSR lookup when source results are useful.
- Gives source-evaluation and citation guidance.
- Refuses assignment-completion, paywalled full-text summaries, and invented resource links.

## Research Modes

Students can choose:

- Scholarly Articles
- Books and Background Sources
- News and Current Events
- Data and Statistics
- Primary Sources
- Legal or Policy Sources
- General Research

The selected mode affects search terms, recommended platforms, Primo/ZSR lookup behavior, source-evaluation advice, citation reminders, and next steps.

## Local Setup

```bash
npm install
cp .env.example .env
```

Add a server-side Gemini key to `.env`:

```bash
GEMINI_API_KEY=your_key_here
```

Run the app:

```bash
npm run dev
```

Frontend: `http://localhost:5173`  
Express API: `http://localhost:3001`

For a production-style local run:

```bash
npm run build
npm start
```

Open `http://localhost:3001`.

## Required Environment Variables

```bash
GEMINI_API_KEY=
GEMINI_MODEL=gemini-2.5-flash
PORT=3001
LOG_QUERIES=on
RATE_MAX=30
RATE_WINDOW_MS=600000
PRIMO_LIVE=on
PRIMO_API_ENDPOINT=
PRIMO_API_KEY=
VITE_WFU_LIBKEY_LIBRARY_ID=
```

Only `GEMINI_API_KEY` is required for AI replies. Primo API and LibKey ID values are optional until ZSR confirms official settings.

## Sharing A Demo

For a durable test link, deploy the Node service to Render, Railway, Fly.io, or another host that can run the Express API. The included `render.yaml` is ready for Render.

Private keys must stay server-side. The browser should call only `/api/chat` or `/api/chat/stream`.

For a temporary same-day demo:

```bash
npm run dev
npx cloudflared tunnel --url http://localhost:5173
```

The generated tunnel URL works only while the local dev server and tunnel are running.

## Library Link Configuration

Library URLs and research-mode definitions live in `config/libraryLinks.js`.

Values to confirm with ZSR before a public pilot:

- ZSR citation guide URL
- Zotero Research Assistant URL
- Preferred LibKey Nomad information page
- ZSR Delivers / ILL fallback URL
- Official Primo API endpoint and API key, if ZSR wants API-backed search
- Wake Forest LibKey / Third Iron library ID, if ZSR wants direct LibKey lookup links

## LibKey Nomad Support

The app provides LibKey-aware full-text help. It can point students to LibKey Nomad setup and create DOI/PMID-based access links when the data exists.

It does not control the LibKey Nomad browser extension and does not guarantee full-text access.

## Optional Primo API Readiness

`server/primoApi.js` contains a future-facing service for official Primo API search if `PRIMO_API_ENDPOINT` and `PRIMO_API_KEY` are configured.

Without those credentials, the app falls back to public ZSR/Primo search links and the existing best-effort live lookup.

## Useful Commands

```bash
npm run dev
npm run build
npm start
npm test
npm run test:live
```

`npm run test:live` requires `GEMINI_API_KEY`.

## Project Structure

```text
config/        Library links, research modes, citation links, LibKey helpers
public/        ZSR demo images
server/        Express API, Gemini adapter, Primo lookup, safety checks
src/           React app
test/          Unit and live adversarial tests
```

## GitHub Safety

Before pushing:

- Keep `.env` out of GitHub.
- Commit `.env.example`, not real keys.
- Do not commit `node_modules` or `dist`.
